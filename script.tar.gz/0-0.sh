rm capture*
echo "<<Starting the wireless interface in monitor mode>>"
echo "========================================"
echo "          airmon-ng start wlan0"
echo "========================================"
airmon-ng start wlan0
