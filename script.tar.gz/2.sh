echo "==================================================================================="
echo "pyrit -e hackme -i password.lst -o - passthrough | cowpatty -d - -r capture-01.cap -s hackme"
echo "==================================================================================="
pyrit -e hackme -i password.lst -o - passthrough | cowpatty -d - -r capture-01.cap -s hackme
