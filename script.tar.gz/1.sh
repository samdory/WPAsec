echo "==============================================================="
echo "aircrack-ng -w password.lst -b 00:1D:0F:42:B0:0A capture-01.cap"
echo "==============================================================="
aircrack-ng -w password.lst -b 00:1D:0F:42:B0:0A capture-01.cap
