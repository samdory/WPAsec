echo "===================================================================="
echo "pyrit -e hackme -i password.lst -r capture-01.cap attack_passthrough"
echo "===================================================================="
pyrit -e hackme -i password.lst -r capture-01.cap attack_passthrough
